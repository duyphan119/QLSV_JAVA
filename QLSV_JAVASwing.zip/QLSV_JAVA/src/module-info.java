module QLSV_JAVA {
	requires java.sql;
	requires java.desktop;

}