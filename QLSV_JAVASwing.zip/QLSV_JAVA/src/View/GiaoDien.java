package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import Database.ConnectSQL;
import Database.StudentManager;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ButtonGroup;
import javax.swing.LayoutStyle.ComponentPlacement;

public class GiaoDien {

	private JFrame frmAppsDuy;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GiaoDien window = new GiaoDien();
					window.frmAppsDuy.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	StudentManager manager = new StudentManager();
	protected Vector<Vector<String>> data;
	protected Vector<?> header;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	public GiaoDien() {
		initialize();
		
		
	}
	public static int count=0;//số lần bấm LOAD
	private JTable table;
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAppsDuy = new JFrame();
		frmAppsDuy.setTitle("App's Duy ");
		frmAppsDuy.setBounds(100, 100, 1300, 616);
		frmAppsDuy.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 1266, 559);
		frmAppsDuy.getContentPane().add(panel);
		JPanel panel_1 = new JPanel();
		JButton btnAdd = new JButton("Thêm");
		JButton btnDelete = new JButton("Xoá");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    String Sno = textField.getText();

				    // Kiểm tra sinh viên có trong database hay không
				    if (!manager.checkStudent(Sno)) throw new Exception("Sinh viên không tồn tại, không thể xoá!");
				    manager.delete(Sno);

				    // Cập nhật lại dữ liệu hiển thị trên phần mềm
				    data = manager.getAll();
				    ((DefaultTableModel) (table.getModel())).setDataVector(data, header);

				    // Thông báo xóa thành công
				    JOptionPane.showMessageDialog(panel, "Xoá thành công!", "Sucess", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
				    JOptionPane.showMessageDialog(panel, "Xoá thất bại\nDetails:" + e1, "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		JButton btnLoad = new JButton("Xem thông \r\n\ttin");
		JScrollPane scrollPane = new JScrollPane();
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Tạo giao diện cho người dùng nhập username và password của database
					JPanel inputPane = new JPanel();
					inputPane.setLayout(new GridLayout(0, 2, 2, 2));
					JLabel label1 = new JLabel("SQL username: ");
					label1.setFont(new Font("Tahoma", Font.BOLD, 18));
					JLabel label2 = new JLabel("SQL password: ");
					label2.setFont(new Font("Tahoma", Font.BOLD, 18));

					// Tạo nơi điền username và password
					JTextField userName = new JTextField();
					JPasswordField passWord = new JPasswordField();
					inputPane.add(label1);
					inputPane.add(userName);
					inputPane.add(label2);
					inputPane.add(passWord);
					
					if(count==0) {
						if (JOptionPane.showConfirmDialog(panel, inputPane,
				                "Đăng nhập SQL", JOptionPane.YES_NO_OPTION,
				                JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {

						    // Lấy username và password
						    String user = userName.getText();
						    String pass = passWord.getText();
						    if ((user.isEmpty()) || (pass.isEmpty())) throw new Exception("Input was not correct");
						    ConnectSQL.dbUser = user;
						    ConnectSQL.dbPass = pass;
						    scrollPane.setVisible(true);
						} else throw new Exception("Canceled by user");
					}

					// Tải dữ liệu từ database vào phần mềm
					data = manager.getAll();

					// Thiết kế bảng dữ liệu để hiển thị (add title của scrollPane)
					Vector<String>header = new Vector<String>();
					header.add("MSSV");
					header.add("Tên");
					header.add("Giới tính");
					header.add("Lớp");
					header.add("Địa chỉ");
					header.add("Email cá nhân");
					((DefaultTableModel) (table.getModel())).setDataVector(data, header);
					
					//Tắt thông báo đăng nhập
					count=1;

					// Thông báo thành công
					JOptionPane.showMessageDialog(panel, "Load sucess!");

				    } catch (Exception e1) {
					JOptionPane.showMessageDialog(panel, "Load failure!\nDetails: " + e1);
				    }
			}
		});
		btnLoad.setFont(new Font("Sitka Small", Font.BOLD, 27));
		
		
		panel_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel = new JLabel("MSSV");
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Tên");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_1.setColumns(10);
		
		JLabel lblGender = new JLabel("Giới tính");
		lblGender.setHorizontalAlignment(SwingConstants.TRAILING);
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblClass = new JLabel("Lớp");
		lblClass.setHorizontalAlignment(SwingConstants.TRAILING);
		lblClass.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_3.setColumns(10);
		
		JLabel lblAddress = new JLabel("Địa chỉ");
		lblAddress.setHorizontalAlignment(SwingConstants.TRAILING);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_4.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.TRAILING);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_5.setColumns(10);
	
		JRadioButton radioF = new JRadioButton("Nam");
		buttonGroup.add(radioF);
		JRadioButton radioM = new JRadioButton("Nữ");
		buttonGroup.add(radioM);
		
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    //Lấy dữ liệu nhập trên phần mềm
				    String Sno = textField.getText();
				    String Sname = textField_1.getText();
				    String Sgender = getGender();
				    String Sclass = textField_3.getText();
				    String Sadress = textField_4.getText();
				    String Semail = textField_5.getText();

				    // Kiểm tra dữ liệu nhập vào, kiểm tra trùng khóa chính trong database
				    if (manager.checkStudent(Sno)) throw new Exception("Đã có sinh viên, nhập lại MSSV");
				    if (!DieuKien.checkIdFormat(Sno)) throw new Exception("MSSV không được chứa khoảng trắng");
				    if (!DieuKien.checkNameFormat(Sname)) throw new Exception("Tên sinh viên không được chứa ký tự đặc biệt");
				    if (!DieuKien.checkNameFormat(Sclass)) throw new Exception("Mã lớp không được được chứa ký tự đặc biệt");
				    else  if (!DieuKien.checkIdFormat(Sclass)) throw new Exception("Mã lớp không được được chứa khoảng trắng");
				    if (!DieuKien.checkNameFormat(Sadress)) throw new Exception("Địa chỉ không được chứa ký tự đặc biệt");
				    // Thêm dữ liệu vào database
				    manager.addNew(Sno, Sname, Sgender, Sclass, Sadress, Semail);

				    // Cập nhật hiển thị database cho phần mềm
				    data = manager.getAll();
				    ((DefaultTableModel) (table.getModel())).setDataVector(data, header);

				    // Thông báo thành công
				    JOptionPane.showMessageDialog(panel, "Thêm thành công!", "Sucess", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
				    JOptionPane.showMessageDialog(panel, "Thêm thất bại\nDetails: " + e1, "Error", JOptionPane.ERROR_MESSAGE);
				}
			}

			private String getGender() {
				// TODO Auto-generated method stub
				if(radioM.isSelected()) {
					return radioM.getText();
				}
				if(radioF.isSelected()) {
					return radioF.getText();
				}
				return null;
			}
		});
		btnAdd.setBackground(Color.MAGENTA);
		btnAdd.setForeground(Color.BLACK);
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		
		btnDelete.setForeground(Color.BLACK);
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDelete.setBackground(Color.RED);
		
		radioM.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		
		radioF.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JButton btnPrint = new JButton("Đăng xuất");
		btnPrint.setBackground(new Color(255, 69, 0));
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				count=0;
				if (JOptionPane.showConfirmDialog(panel, "Bạn có chắc chắn thoát không?",
		                "??????????????", JOptionPane.YES_NO_OPTION,
		                JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
					scrollPane.setVisible(false);
					JOptionPane.showMessageDialog(panel, "Đăng xuất thành công");
				} 
				
			}
		});
		btnPrint.setFont(new Font("Sitka Small", Font.BOLD, 27));
		
		JButton btnGuide = new JButton("Hướng dẫn");
		btnGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(panel, "Bấm LOAD lần đầu để đăng nhập vào SQL, những lần sau là load thông tin vừa ADD. \nBấm Delete (chỉ cần nhập "
						+ "MSSV cần xoá là được, rảnh thì nhập đầy đủ thông tin)");
			}
		});
		btnGuide.setFont(new Font("Sitka Small", Font.BOLD, 27));
		
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 978, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
							.addComponent(btnLoad, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnPrint, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnGuide, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE))
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(btnLoad, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnGuide, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 286, GroupLayout.PREFERRED_SIZE)
							.addGap(14)
							.addComponent(btnPrint, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 558, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(8)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblGender, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(radioM)
							.addGap(7)
							.addComponent(radioF))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblClass, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblAddress, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblEmail, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_panel_1.createSequentialGroup()
							.addComponent(btnAdd, GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(8)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(10)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(7)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(3)
							.addComponent(lblGender))
						.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
							.addComponent(radioM, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
							.addComponent(radioF, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))
					.addGap(8)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblClass)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(10)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblAddress)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(10)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblEmail)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(16)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAdd, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)))
		);
		panel_1.setLayout(gl_panel_1);
		panel.setLayout(gl_panel);
		frmAppsDuy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
