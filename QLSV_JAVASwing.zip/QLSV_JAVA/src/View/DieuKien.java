package View;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DieuKien{

	public static boolean checkIdFormat(String sclass) {
		// TODO Auto-generated method stub
		Pattern p=Pattern.compile("[\\t\\n\\x0B\\f\\r]");
		Matcher m=p.matcher(sclass);
		if(m.find()) {
			return false;
		}
		return true;
	}

	public static boolean checkNameFormat(String sname) {
		Pattern p=Pattern.compile("[a-z0-9A-Z]");
		Matcher m=p.matcher(sname);
		if(m.find()) {
			return true;
		}
		return false;
	}

}
