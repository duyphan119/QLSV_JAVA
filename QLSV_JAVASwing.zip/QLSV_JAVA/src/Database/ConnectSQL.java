package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectSQL {
	public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static String dbURL = "jdbc:sqlserver://localhost:52211;databaseName=Hocdatabase";
	public static String dbUser = "";
    public static String dbPass = "";	
	    
	public Connection getConnect() throws ClassNotFoundException, SQLException {
		Class.forName(ConnectSQL.driverName);
		Connection connection = DriverManager.getConnection(ConnectSQL.dbURL, ConnectSQL.dbUser, ConnectSQL.dbPass);
		return connection;
	}
}	
