package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class StudentManager extends ConnectSQL{
	public Vector<Vector<String>> getAll() throws ClassNotFoundException, SQLException {
		Vector<Vector<String>> data = new Vector<>();
		
		// Kết nối database
		Connection connection = getConnect();

		// Tạo câu lệnh SQL (Cách 1: dùng Statement)
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery("Select * from SinhVien");
		
		while (rs.next()) {

		    // Lấy dữ liệu từ ResultSet
		    String Sno = rs.getString(1);
		    String Sname = rs.getString(2);
		    String Sgender = rs.getString(3);
		    String Sclass = rs.getString(4);
		    String Saddress = rs.getString(5);
		    String Semail = rs.getString(6);

		    // Ghi vào vector
		    Vector<String> temp = new Vector<>();
		    temp.add(Sno);
		    temp.add(Sname);
		    temp.add(Sgender);
		    temp.add(Sclass);
		    temp.add(Saddress);
		    temp.add(Semail);

		    // Thêm dữ liệu vào data vector chính
		    data.add(temp);
		}
		return data;
	}
	public void addNew(String Sno, String Sname, String Sgender, String Sclass, String Sadress, String Semail)
            throws ClassNotFoundException, SQLException {
		// Kết nối database
		Connection connection = getConnect();
		
		// Tạo câu lệnh SQL (Cách 2: sử dụng PreparedStatement)
		String sql = "INSERT INTO SinhVien(Sno,Sname,Sgender,Sclass,Sadress,Semail) VALUES(?,?,?,?,?,?)";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, Sno);
		stmt.setString(2, Sname);
		stmt.setString(3, Sgender);
		stmt.setString(4, Sclass);
		stmt.setString(5, Sadress);
		stmt.setString(6, Semail);
		
		// Thực hiện lệnh SQL
		stmt.executeUpdate();
		
		// Đóng kết nối
		connection.close();
	}
	public int delete(String Sno) throws SQLException, ClassNotFoundException {
		int deleteStatus = 0;

		// Kết nối database
		Connection connection = getConnect();

		// Xóa sinh viên
		String sql = "DELETE FROM SinhVien WHERE Sno='" + Sno + "'";
		Statement stm1 = connection.createStatement();
		deleteStatus = stm1.executeUpdate(sql);

		// Trả về kết quả int (có xóa thành công hay không)
		connection.close();
		return deleteStatus;
	}
	public boolean checkStudent(String sno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = getConnect();
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery("Select * from SinhVien");
		while(rs.next()) {
			if(sno.equals(rs.getString(1))) {
				return true;
			}
		}
		
		return false;
	}
}
